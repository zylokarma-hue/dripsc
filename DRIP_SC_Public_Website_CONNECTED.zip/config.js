// DRIP.SC Supabase backend settings
const SUPABASE_URL = "https://xhneebkntfebombiansr.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_4jmvyo0R3mQ3y6fK_NztrQ_0nK4kdEM";
