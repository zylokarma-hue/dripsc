# DRIP.SC Public Website

This is the public DRIP.SC site. Visitors can submit photos/videos. Every submission starts as `pending` and is invisible on the public Wall until you approve it in the private Admin dashboard.

## Backend setup
1. Create a Supabase project.
2. Open SQL Editor and run `schema.sql` after replacing `YOUR_ADMIN_EMAIL` with your admin email.
3. Create your admin account in Supabase Authentication using that same email.
4. Copy the Supabase Project URL and anon/public key into `config.js`. Never use a service-role key in this website.
5. Use the separate DRIP.SC Admin download for moderation.

The current visual design is preserved from your uploaded DRIP.SC website.
