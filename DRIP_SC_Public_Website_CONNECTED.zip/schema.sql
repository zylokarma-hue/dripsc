create extension if not exists pgcrypto;
create table if not exists public.submissions (
 id uuid primary key default gen_random_uuid(), created_at timestamptz not null default now(),
 first_name text not null, last_name text not null, social text not null, email text not null,
 player_team text, category text not null, title text, description text, media_url text,
 status text not null default 'pending' check(status in ('pending','approved','rejected'))
);
alter table public.submissions enable row level security;
create policy "public submit pending" on public.submissions for insert to anon, authenticated with check(status='pending');
create policy "public view approved" on public.submissions for select to anon, authenticated using(status='approved');
-- Replace YOUR_ADMIN_EMAIL below with YOUR email before running.
create policy "admin read" on public.submissions for select to authenticated using((auth.jwt()->>'email')='YOUR_ADMIN_EMAIL');
create policy "admin update" on public.submissions for update to authenticated using((auth.jwt()->>'email')='YOUR_ADMIN_EMAIL') with check((auth.jwt()->>'email')='YOUR_ADMIN_EMAIL');
create policy "admin delete" on public.submissions for delete to authenticated using((auth.jwt()->>'email')='YOUR_ADMIN_EMAIL');
insert into storage.buckets(id,name,public) values('submissions','submissions',true) on conflict(id) do update set public=true;
create policy "public upload media" on storage.objects for insert to anon,authenticated with check(bucket_id='submissions');
create policy "public read media" on storage.objects for select to anon,authenticated using(bucket_id='submissions');
